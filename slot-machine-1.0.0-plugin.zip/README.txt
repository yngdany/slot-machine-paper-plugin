SlotMachine
===========

Target: Paper 1.21.x

Dependencies:
- Vault (soft dependency)
- A Vault-compatible economy provider such as EssentialsX

Install:
1. Build with `mvn package`.
2. Copy `target/slot-machine-1.0.0.jar` to `plugins/`.
3. Install Vault and an economy provider.
4. Start the server and edit plugins/SlotMachine/config.yml.

Commands:
/slotmachine give <type> [player]
/slotmachine list
/slotmachine jackpot [amount|set <amount>|reset]
/slotmachine stats [player]
/slotmachine reload

The give command provides a tagged machine item. Place it to register a protected
machine. Right-click it to open the animated GUI.